import React from 'react';
import { Login } from './Login';

export function AuthContainer() {
  return <Login />;
}