// server/scripts/migrate.ts
import { query } from '../db.js';
import { fileURLToPath } from 'url';
import { basename } from 'path';

export async function runMigrations() {
  const statements = [
    `CREATE EXTENSION IF NOT EXISTS pgcrypto;`,
    `
    CREATE TABLE IF NOT EXISTS users (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      email text UNIQUE NOT NULL,
      password_hash text NOT NULL,
      role text NOT NULL DEFAULT 'admin',
      created_at timestamptz NOT NULL DEFAULT now()
    );`,
    `
    CREATE TABLE IF NOT EXISTS kitchens (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      name text NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    );`,
    `
    INSERT INTO users (email, password_hash, role)
    VALUES ('admin@example.com', crypt('admin123', gen_salt('bf')), 'admin')
    ON CONFLICT (email) DO NOTHING;
    `
  ];

  for (const sql of statements) {
    try {
      await query(sql);
    } catch (err) {
      console.error('❌ Migration failed for SQL:\n' + sql + '\n---\n', err);
      throw err;
    }
  }

  console.log('✅ Migrations complete');
}

// Allow running this file directly: `npm run migrate`
const isDirect = basename(fileURLToPath(import.meta.url)).startsWith('migrate');
if (isDirect) {
  runMigrations()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}