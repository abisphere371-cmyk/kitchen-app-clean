import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth } from '../auth.js';

const router = Router();

// Validation schema for customer
const customerSchema = z.object({
  name: z.string().min(1),
  email: z.string().email().optional().nullable(),
  phone: z.string().min(1),
  address: z.string().optional().nullable(),
  preferences: z.record(z.string(), z.any()).optional(),
  is_active: z.boolean().optional()
});

// Get all customers
router.get('/', requireAuth, async (req, res) => {
  try {
    const result = await query(`
      SELECT * FROM customers 
      ORDER BY name
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Get customers error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Create new customer
router.post('/', requireAuth, async (req, res) => {
  try {
    // Validate request body
    const validatedData = customerSchema.parse(req.body);
    
    const result = await query(`
      INSERT INTO customers (
        name, email, phone, address, preferences, is_active
      ) VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `, [
      validatedData.name,
      validatedData.email,
      validatedData.phone,
      validatedData.address,
      JSON.stringify(validatedData.preferences || {}),
      validatedData.is_active !== false
    ]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    console.error('Create customer error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Update customer
router.put('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate request body
    const validatedData = customerSchema.parse(req.body);
    
    const result = await query(`
      UPDATE customers 
      SET name = $1, email = $2, phone = $3, address = $4, 
          preferences = $5, is_active = $6, updated_at = NOW()
      WHERE id = $7
      RETURNING *
    `, [
      validatedData.name,
      validatedData.email,
      validatedData.phone,
      validatedData.address,
      JSON.stringify(validatedData.preferences || {}),
      validatedData.is_active,
      id
    ]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Customer not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    console.error('Update customer error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Delete customer
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await query(`
      DELETE FROM customers 
      WHERE id = $1
      RETURNING *
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Customer not found' });
    }
    
    res.json({ message: 'Customer deleted successfully' });
  } catch (error) {
    console.error('Delete customer error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

export default router;
