import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth, hashPassword } from '../auth.js';

const router = Router();

// Validation schema for staff member
const staffSchema = z.object({
  name: z.string().min(1),
  email: z.string().email().optional().nullable(),
  phone: z.string().min(1),
  role: z.string().min(1),
  department: z.string().optional().nullable(),
  salary: z.number().min(0).optional(),
  username: z.string().min(1),
  password: z.string().min(6).optional(),
  is_active: z.boolean().optional()
});

// Get all staff members
router.get('/', requireAuth, async (req, res) => {
  try {
    const result = await query(`
      SELECT id, name, email, phone, role, department, salary, username, is_active, created_at, updated_at
      FROM staff_members 
      ORDER BY name
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Get staff members error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Create new staff member
router.post('/', requireAuth, async (req, res) => {
  try {
    // Validate request body
    const validatedData = staffSchema.parse(req.body);
    
    // Hash password if provided
    let hashedPassword = null;
    if (validatedData.password) {
      hashedPassword = await hashPassword(validatedData.password);
    }
    
    const result = await query(`
      INSERT INTO staff_members (
        name, email, phone, role, department, salary, username, password_hash, is_active
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id, name, email, phone, role, department, salary, username, is_active, created_at, updated_at
    `, [
      validatedData.name,
      validatedData.email,
      validatedData.phone,
      validatedData.role,
      validatedData.department,
      validatedData.salary || null,
      validatedData.username,
      hashedPassword,
      validatedData.is_active !== false
    ]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    console.error('Create staff member error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Update staff member
router.put('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate request body
    const validatedData = staffSchema.parse(req.body);
    
    // Hash password if provided
    let passwordUpdate = '';
    const params = [
      validatedData.name,
      validatedData.email,
      validatedData.phone,
      validatedData.role,
      validatedData.department,
      validatedData.salary || null,
      validatedData.username,
      validatedData.is_active,
      id
    ];
    
    if (validatedData.password) {
      const hashedPassword = await hashPassword(validatedData.password);
      passwordUpdate = ', password_hash = $9';
      params.splice(8, 0, hashedPassword); // Insert hashed password at position 9
    }
    
    const result = await query(`
      UPDATE staff_members 
      SET name = $1, email = $2, phone = $3, role = $4, department = $5, 
          salary = $6, username = $7, is_active = $8${passwordUpdate}, updated_at = NOW()
      WHERE id = $${passwordUpdate ? '10' : '9'}
      RETURNING id, name, email, phone, role, department, salary, username, is_active, created_at, updated_at
    `, params);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Staff member not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    console.error('Update staff member error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Delete staff member
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await query(`
      DELETE FROM staff_members 
      WHERE id = $1
      RETURNING *
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Staff member not found' });
    }
    
    res.json({ message: 'Staff member deleted successfully' });
  } catch (error) {
    console.error('Delete staff member error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

export default router;
