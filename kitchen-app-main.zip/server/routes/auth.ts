import { Router, type Request, type Response } from 'express';
import jwt from 'jsonwebtoken';
import { query } from '../db.js';
import { signJwt, comparePassword, requireAuth } from '../auth.js';
import { hashPassword } from '../auth.js';

const router = Router();

// POST /api/auth/login
router.post('/login', async (req: Request, res: Response) => {
  const { email, username, password } = req.body || {};
  try {
    // example: allow login by email or username
    const field = email ? 'email' : 'username';
    const value = email ?? username;

    const { rows } = await query(
      `SELECT id, username, email, password_hash, role, name, phone FROM users WHERE ${field} = $1 AND active = true LIMIT 1`,
      [value]
    );

    const user = rows[0];
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });

    const ok = await comparePassword(password, user.password_hash);
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' });

    const token = signJwt({ id: user.id, role: user.role, username: user.username, email: user.email });

    return res.json({ 
      access_token: token, 
      user: { 
        id: user.id, 
        username: user.username, 
        email: user.email, 
        role: user.role,
        name: user.name,
        phone: user.phone
      } 
    });
  } catch (e) {
    console.error('login error', e);
    return res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/auth/me
router.get('/me', requireAuth, async (req: Request, res: Response) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  try {
    const result = await query(
      'SELECT id, email, name, role, phone FROM users WHERE id = $1 AND active = true', 
      [req.user.id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    return res.json({ user: result.rows[0] });
  } catch (error) {
    console.error('Get user error:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

export default router;