import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth } from '../auth.js';

const router = Router();

// Validation schema for supplier
const supplierSchema = z.object({
  name: z.string().min(1),
  contact: z.string().min(1),
  email: z.string().email().optional().nullable(),
  address: z.string().optional().nullable(),
  categories: z.array(z.string()).optional(),
  rating: z.number().min(0).max(5).optional(),
  is_active: z.boolean().optional()
});

// Get all suppliers
router.get('/', requireAuth, async (req, res) => {
  try {
    const result = await query(`
      SELECT * FROM suppliers 
      ORDER BY name
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Get suppliers error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Create new supplier
router.post('/', requireAuth, async (req, res) => {
  try {
    // Validate request body
    const validatedData = supplierSchema.parse(req.body);
    
    const result = await query(`
      INSERT INTO suppliers (
        name, contact, email, address, categories, rating, is_active
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `, [
      validatedData.name,
      validatedData.contact,
      validatedData.email,
      validatedData.address,
      JSON.stringify(validatedData.categories || []),
      validatedData.rating || null,
      validatedData.is_active !== false
    ]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    console.error('Create supplier error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Update supplier
router.put('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate request body
    const validatedData = supplierSchema.parse(req.body);
    
    const result = await query(`
      UPDATE suppliers 
      SET name = $1, contact = $2, email = $3, address = $4, 
          categories = $5, rating = $6, is_active = $7, updated_at = NOW()
      WHERE id = $8
      RETURNING *
    `, [
      validatedData.name,
      validatedData.contact,
      validatedData.email,
      validatedData.address,
      JSON.stringify(validatedData.categories || []),
      validatedData.rating || null,
      validatedData.is_active,
      id
    ]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Supplier not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    console.error('Update supplier error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Delete supplier
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await query(`
      DELETE FROM suppliers 
      WHERE id = $1
      RETURNING *
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Supplier not found' });
    }
    
    res.json({ message: 'Supplier deleted successfully' });
  } catch (error) {
    console.error('Delete supplier error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

export default router;
